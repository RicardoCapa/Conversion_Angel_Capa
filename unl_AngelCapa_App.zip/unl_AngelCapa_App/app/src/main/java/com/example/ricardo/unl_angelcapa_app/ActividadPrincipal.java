package com.example.ricardo.unl_angelcapa_app;

import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class ActividadPrincipal extends AppCompatActivity implements View.OnClickListener {
    Button a, b;
    EditText caja;
    TextView res;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actividad_principal);
        caja = (EditText) findViewById(R.id.txtGrados);
        a = (Button) findViewById(R.id.btnFa);
        b = (Button) findViewById((R.id.btnCelsius));
        res = (TextView) findViewById((R.id.lblResult)) ;
        a.setOnClickListener(this);
        b.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnFa:
                Double num1 = Double.parseDouble(caja.getText().toString());
                Double div = 1.8;
                Double respuesta = (num1 * div) + 32;
                res.setText("Expresado en Grados Farenheit " + respuesta );

                break;
            case R.id.btnCelsius:
                Double num2 = Double.parseDouble(caja.getText().toString());
                Double aux = (num2 - 32) * 5/9;
                res.setText("Expresado en Grados Celsius " + aux );
                break;
        }
    }
}
